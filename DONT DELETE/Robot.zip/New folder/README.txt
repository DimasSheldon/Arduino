1. Masukkan folder Actuator, BlinkLED, DistanceSensor ke 
Library Arduino (C:\Program Files (x86)\Arduino\libraries)

2. Compile & upload program utama (Robot.ino) yg ada di folder Robot